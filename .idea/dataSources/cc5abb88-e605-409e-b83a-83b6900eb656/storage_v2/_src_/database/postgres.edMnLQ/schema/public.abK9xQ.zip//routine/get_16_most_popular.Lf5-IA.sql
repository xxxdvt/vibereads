create function get_16_most_popular() returns integer[]
    language plpgsql
as
$$
begin
    return array(
        select book_id
        from ratings
        group by book_id
        order by coalesce(avg(rating), 0) desc
        limit 16
    );
end;
$$;

alter function get_16_most_popular() owner to postgres;

