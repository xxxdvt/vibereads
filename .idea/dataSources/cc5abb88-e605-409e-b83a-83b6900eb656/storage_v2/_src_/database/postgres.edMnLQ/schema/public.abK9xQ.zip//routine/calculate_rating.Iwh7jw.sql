create function calculate_rating(cur_book_id integer) returns real
    language plpgsql
as
$$
begin
    return coalesce((select avg(rating) from ratings where book_id = cur_book_id), 0);
end;
$$;

alter function calculate_rating(integer) owner to postgres;

